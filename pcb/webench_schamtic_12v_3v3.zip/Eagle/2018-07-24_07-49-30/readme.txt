 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\49\\97\\4997447\\6\Eagle\2018-07-24_07-49-30\2018-07-24_07-49-30
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "O1017720590600000P00200P00000" renamed to "O101772059060000"
Component "SRR4028-3R3Y" renamed to "SRR4028-3R3Y"
Component "C1608X5R1A226M080AC" renamed to "C1608X5R1A226M080AC"
Component "GRM033R61A822KA01D" renamed to "GRM033R61A822KA01D"
Component "CRCW040233K2FKED" renamed to "CRCW040233K2FKED"
Component "TPS562219DDFR" renamed to "TPS562219DDFR"
Component "C0603C104Z3VACTU" renamed to "C0603C104Z3VACTU"
Component "C2012X5R1V226M125AC" renamed to "C2012X5R1V226M125AC"
Component "WB_GND" renamed to "WB_GND"
Component "RMCF0402FT10K0" renamed to "RMCF0402FT10K0"
Component "ERJ-6ENF1003V" renamed to "ERJ-6ENF1003V"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "WB_BATTERY" renamed to "WB_BATTERY"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CFF_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS562219DDF was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS562219DDF was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS562219DDF was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX79Y209D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX26Y38D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "O101772059060000" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX44Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX14Y13D0T" Shape(4) is a CIRCLE with no diameter.
Message - Pattern "SRR4028", entity (115-Line) is a LINE with matching start and end points.
Message - Pattern "SRR4028", entity (117-Line) is a LINE with matching start and end points.
Message - Pattern "SRR4028", entity (119-Line) is a LINE with matching start and end points.
Message - Pattern "SRR4028", entity (121-Line) is a LINE with matching start and end points.
Message - Component "SRR4028-3R3Y" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRR4028-3R3Y" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRR4028-3R3Y" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1A226M080AC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1A226M080AC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1A226M080AC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1A226M080AC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1A226M080AC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R61A822KA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040233K2FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040233K2FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040233K2FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0603C104Z3VACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0603C104Z3VACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0603C104Z3VACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0603C104Z3VACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RMCF0402FT10K0" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RMCF0402FT10K0" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RMCF0402FT10K0" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RMCF0402FT10K0" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1003V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1003V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1003V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   6
Pattern count:    6
Symbol count:     21
Component count:  12

Export

Component "WB_GND" has no mapped footprint will be skipped.
Component "WB_CURRENT_LOAD" has no mapped footprint will be skipped.
Component "WB_BATTERY" has no mapped footprint will be skipped.
